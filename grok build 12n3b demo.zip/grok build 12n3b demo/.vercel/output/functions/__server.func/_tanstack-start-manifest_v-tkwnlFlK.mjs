//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tkwnlFlK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/architecture",
			"/disclosures",
			"/observer",
			"/registry",
			"/evaluations/$requestId"
		],
		preloads: [
			"/assets/index-zLcrp3nW.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/registry-BJUtlYxZ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-zLcrp3nW.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-r7QQxYfD.js", "/assets/button-BoCIShmm.js"]
	},
	"/evaluations/$requestId": {
		filePath: "/workspace/src/routes/evaluations.$requestId.tsx",
		children: void 0,
		preloads: ["/assets/evaluations._requestId-L6Us7hpn.js", "/assets/button-BoCIShmm.js"]
	}
} });
//#endregion
export { tsrStartManifest };
