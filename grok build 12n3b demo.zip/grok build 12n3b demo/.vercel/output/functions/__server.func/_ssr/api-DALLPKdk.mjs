import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DALLPKdk.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ERROR_CATALOG = {
	INVALID_INPUT: {
		httpish: 400,
		retryable: false,
		terminal: true,
		meaning: "Input failed validation or canonicalization. May produce REJECT if persisted."
	},
	INPUT_TOO_LARGE: {
		httpish: 413,
		retryable: false,
		terminal: false,
		meaning: "Request exceeds size limit. No decision is issued and nothing is stored."
	},
	RATE_LIMITED: {
		httpish: 429,
		retryable: true,
		terminal: false,
		meaning: "Abuse control. No decision is issued."
	},
	AUDIT_PERSISTENCE_FAILURE: {
		httpish: 503,
		retryable: true,
		terminal: false,
		meaning: "Terminal decision cannot be exposed without a durable audit record."
	},
	NOT_FOUND: {
		httpish: 404,
		retryable: false,
		terminal: false,
		meaning: "No audit record for the requested identity."
	},
	UNKNOWN_STATE: {
		httpish: 500,
		retryable: false,
		terminal: false,
		meaning: "Runtime produced a state outside SHIP, HOLD, and REJECT. Fail-closed: no decision."
	}
};
var EngineError = class extends Error {
	code;
	retryable;
	terminal;
	constructor(code, message) {
		super(message ?? ERROR_CATALOG[code].meaning);
		this.name = "EngineError";
		this.code = code;
		this.retryable = ERROR_CATALOG[code].retryable;
		this.terminal = ERROR_CATALOG[code].terminal;
	}
	toJSON() {
		return {
			code: this.code,
			message: this.message,
			retryable: this.retryable,
			terminal: this.terminal
		};
	}
};
var api_exports = /* @__PURE__ */ __exportAll({
	exportEvaluation_createServerFn_handler: () => exportEvaluation_createServerFn_handler,
	getEvaluation_createServerFn_handler: () => getEvaluation_createServerFn_handler,
	getManifest_createServerFn_handler: () => getManifest_createServerFn_handler,
	listEvaluations_createServerFn_handler: () => listEvaluations_createServerFn_handler,
	submitEvaluation_createServerFn_handler: () => submitEvaluation_createServerFn_handler,
	verifyEvaluation_createServerFn_handler: () => verifyEvaluation_createServerFn_handler
});
var SubmitSchema = object({
	text: string().min(1).max(8e3),
	evidenceClass: _enum([
		"synthetic",
		"static_fixture",
		"customer_provided",
		"live_retrieved"
	]),
	scenarioId: string().max(80).nullable().optional()
});
var IdSchema = object({ requestId: string().min(3).max(80) });
function asError(err) {
	if (err instanceof EngineError) return {
		ok: false,
		error: err.toJSON()
	};
	return {
		ok: false,
		error: {
			code: "UNKNOWN_STATE",
			message: err instanceof Error ? err.message : "Unspecified runtime failure.",
			retryable: false,
			terminal: false
		}
	};
}
var getManifest_createServerFn_handler = createServerRpc({
	id: "578940d511c5410f89c5d1bba94d1836f252b2267a21973e21d7119104a4e224",
	name: "getManifest",
	filename: "src/lib/emo1/api.ts"
}, (opts) => getManifest.__executeServer(opts));
var getManifest = createServerFn({ method: "GET" }).handler(getManifest_createServerFn_handler, async () => {
	const { runtimeManifest, ensureSeeded } = await import("./persist.server-DYGZUT-U.mjs");
	await ensureSeeded();
	return runtimeManifest();
});
var submitEvaluation_createServerFn_handler = createServerRpc({
	id: "2afc27d4cdc16c98d459bb4e2a9a8a44dba9d4da0c593754fcfc752dc60a3d03",
	name: "submitEvaluation",
	filename: "src/lib/emo1/api.ts"
}, (opts) => submitEvaluation.__executeServer(opts));
var submitEvaluation = createServerFn({ method: "POST" }).inputValidator((data) => SubmitSchema.parse(data)).handler(submitEvaluation_createServerFn_handler, async ({ data }) => {
	try {
		const { executeAndPersist, ensureSeeded } = await import("./persist.server-DYGZUT-U.mjs");
		await ensureSeeded();
		return {
			ok: true,
			record: await executeAndPersist({
				text: data.text,
				evidenceClass: data.evidenceClass,
				scenarioId: data.scenarioId
			})
		};
	} catch (err) {
		return asError(err);
	}
});
var getEvaluation_createServerFn_handler = createServerRpc({
	id: "3ce5a3f45e9adda2330d8afbe4156efff2cac0d7befb91e23c9806055dbe798b",
	name: "getEvaluation",
	filename: "src/lib/emo1/api.ts"
}, (opts) => getEvaluation.__executeServer(opts));
var getEvaluation = createServerFn({ method: "POST" }).inputValidator((data) => IdSchema.parse(data)).handler(getEvaluation_createServerFn_handler, async ({ data }) => {
	try {
		const { getRecord, ensureSeeded } = await import("./persist.server-DYGZUT-U.mjs");
		await ensureSeeded();
		const record = await getRecord(data.requestId);
		if (!record) throw new EngineError("NOT_FOUND", "No audit record for that request id.");
		return {
			ok: true,
			record
		};
	} catch (err) {
		return asError(err);
	}
});
var listEvaluations_createServerFn_handler = createServerRpc({
	id: "3ab7957fa786e7d5570410ed935e7f3f859e98401337f0d23a119efd68cc9306",
	name: "listEvaluations",
	filename: "src/lib/emo1/api.ts"
}, (opts) => listEvaluations.__executeServer(opts));
var listEvaluations = createServerFn({ method: "GET" }).handler(listEvaluations_createServerFn_handler, async () => {
	const { listRecords, ensureSeeded, runtimeManifest } = await import("./persist.server-DYGZUT-U.mjs");
	await ensureSeeded();
	return {
		ok: true,
		rows: await listRecords(),
		manifest: runtimeManifest()
	};
});
var verifyEvaluation_createServerFn_handler = createServerRpc({
	id: "1bfdaa3eb74c42e548f3c668de8d652dd73f2385ce4b2112eaac63308115e119",
	name: "verifyEvaluation",
	filename: "src/lib/emo1/api.ts"
}, (opts) => verifyEvaluation.__executeServer(opts));
var verifyEvaluation = createServerFn({ method: "POST" }).inputValidator((data) => IdSchema.parse(data)).handler(verifyEvaluation_createServerFn_handler, async ({ data }) => {
	const { getRecord, ensureSeeded } = await import("./persist.server-DYGZUT-U.mjs");
	const { verifyRecord, runEngine } = await import("./engine-CBurm1IE.mjs");
	await ensureSeeded();
	const record = await getRecord(data.requestId);
	if (!record) return {
		ok: false,
		error: new EngineError("NOT_FOUND").toJSON()
	};
	const integrity = verifyRecord(record);
	const replay = runEngine({
		originalText: record.original_input,
		evidenceClass: record.evidence_class,
		scenarioId: record.scenario_id,
		nowIso: record.audit.decided_at,
		prevChainHash: record.audit.prev_chain_hash,
		sourceCommit: "workspace"
	});
	return {
		ok: true,
		integrity,
		replay: {
			match: replay.decision === record.decision && replay.decision_lineage.rule_id === record.decision_lineage.rule_id,
			stored_decision: record.decision,
			replayed_decision: replay.decision,
			stored_rule: record.decision_lineage.rule_id,
			replayed_rule: replay.decision_lineage.rule_id,
			note: "Replay uses recorded original input and current engine. Evaluator output hashes may differ by timestamp; terminal mapping should match."
		}
	};
});
var exportEvaluation_createServerFn_handler = createServerRpc({
	id: "87452eb25cb65d49e2607eb1c20c2cdefc6f58bd17cb2e707e08d7fcd729bd77",
	name: "exportEvaluation",
	filename: "src/lib/emo1/api.ts"
}, (opts) => exportEvaluation.__executeServer(opts));
var exportEvaluation = createServerFn({ method: "POST" }).inputValidator((data) => IdSchema.parse(data)).handler(exportEvaluation_createServerFn_handler, async ({ data }) => {
	const { getRecord, ensureSeeded, runtimeManifest } = await import("./persist.server-DYGZUT-U.mjs");
	const { verifyRecord } = await import("./engine-CBurm1IE.mjs");
	await ensureSeeded();
	const record = await getRecord(data.requestId);
	if (!record) return {
		ok: false,
		error: new EngineError("NOT_FOUND").toJSON()
	};
	return {
		ok: true,
		package: {
			export_version: "emo1-export-1.0.0",
			exported_at: (/* @__PURE__ */ new Date()).toISOString(),
			manifest: runtimeManifest(),
			integrity: verifyRecord(record),
			record,
			how_to_verify: [
				"Recompute record_hash from request_id, execution_id, original_hash, normalized_hash, decision, rule_id, evaluator output hashes, registry_version, policy_version, artifact_id.",
				"Recompute chain_hash = sha256(prev_chain_hash || emo1-audit-genesis-v1 | record_hash).",
				"Replay original_input through EMO1 $12N3B 1.0.0 and compare terminal state."
			]
		}
	};
});
//#endregion
export { EngineError as n, api_exports as t };
