import { n as EngineError } from "./api-DALLPKdk.mjs";
import { _ as artifactMaterial, c as POLICY_VERSION, f as REGISTRY_VERSION, h as SCHEMA_VERSION, l as PROTECTED_PATHS, m as RUNTIME_VERSION, p as RUNTIME_ID, r as CONSENSUS_VERSION, u as REGISTRY_ID } from "./inventory-dc-eGa2v.mjs";
import { artifactIdOf, i as sha256, idempotencyKey, n as POLICY, r as redactSecrets, runEngine, t as canonicalizeInput } from "./engine-CBurm1IE.mjs";
import { t as SCENARIOS } from "./scenarios-CmXU2MmT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/persist.server-DYGZUT-U.js
var _0002_emo1_default = "create table if not exists evaluations (\n  request_id         text primary key,\n  execution_id       text not null unique,\n  idempotency_key    text not null unique,\n  original_input     text not null,\n  original_hash      text not null,\n  normalized_input   text not null,\n  normalized_hash    text not null,\n  evidence_class     text not null,\n  decision           text not null,\n  rule_id            text not null,\n  record_json        text not null,\n  artifact_id        text not null,\n  runtime_version    text not null,\n  registry_version   text not null,\n  policy_version     text not null,\n  schema_version     text not null,\n  record_hash        text not null,\n  chain_hash         text not null,\n  prev_chain_hash    text,\n  decided_at         timestamptz not null default now(),\n  created_at         timestamptz not null default now()\n);\n\ncreate index if not exists evaluations_decided_at_idx on evaluations (decided_at desc);\ncreate index if not exists evaluations_decision_idx on evaluations (decision);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_emo1.sql": _0002_emo1_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function parseRecord(json) {
	return JSON.parse(json);
}
async function previousChainHash() {
	return (await (await getSql())`
    select chain_hash from evaluations order by decided_at desc, request_id desc limit 1
  `)[0]?.chain_hash ?? null;
}
async function findByIdempotency(key) {
	const rows = await (await getSql())`
    select record_json from evaluations where idempotency_key = ${key} limit 1
  `;
	if (!rows[0]) return null;
	return parseRecord(rows[0].record_json);
}
async function insertRecord(record) {
	const sql = await getSql();
	try {
		await sql`
      insert into evaluations (
        request_id, execution_id, idempotency_key, original_input, original_hash,
        normalized_input, normalized_hash, evidence_class, decision, rule_id,
        record_json, artifact_id, runtime_version, registry_version, policy_version,
        schema_version, record_hash, chain_hash, prev_chain_hash, decided_at
      ) values (
        ${record.request_id},
        ${record.execution_id},
        ${record.idempotency_key},
        ${record.original_input},
        ${record.original_hash},
        ${record.normalized_input},
        ${record.normalized_hash},
        ${record.evidence_class},
        ${record.decision},
        ${record.decision_lineage.rule_id},
        ${JSON.stringify(record)},
        ${record.artifact_id},
        ${record.runtime_version},
        ${record.registry_version},
        ${record.policy_version},
        ${record.schema_version},
        ${record.audit.record_hash},
        ${record.audit.chain_hash},
        ${record.audit.prev_chain_hash},
        ${record.audit.decided_at}
      )
    `;
	} catch (err) {
		const msg = err instanceof Error ? err.message : String(err);
		if (/unique|duplicate/i.test(msg)) {
			if (await findByIdempotency(record.idempotency_key)) return;
		}
		throw new EngineError("AUDIT_PERSISTENCE_FAILURE", "Audit write failed. No decision was published.");
	}
}
async function getRecord(requestId) {
	const rows = await (await getSql())`
    select record_json from evaluations where request_id = ${requestId} limit 1
  `;
	if (!rows[0]) return null;
	return parseRecord(rows[0].record_json);
}
async function listRecords(limit = 40) {
	return (await (await getSql())`
    select request_id, decision, original_input, evidence_class, decided_at,
           record_hash, chain_hash, runtime_version, registry_version, rule_id
    from evaluations
    order by decided_at desc
    limit ${limit}
  `).map((r) => ({
		request_id: r.request_id,
		decision: r.decision,
		original_input: r.original_input,
		evidence_class: r.evidence_class,
		decided_at: r.decided_at,
		record_hash: r.record_hash,
		chain_hash: r.chain_hash,
		rule_id: r.rule_id,
		runtime_version: r.runtime_version,
		registry_version: r.registry_version
	}));
}
var buckets = /* @__PURE__ */ new Map();
function takeRateToken(key = "demo-public") {
	const now = Date.now();
	const windowMs = POLICY.rate_limit_window_ms;
	const prev = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
	if (prev.length >= POLICY.rate_limit_max) {
		buckets.set(key, prev);
		return false;
	}
	prev.push(now);
	buckets.set(key, prev);
	return true;
}
async function executeAndPersist(input) {
	if (!takeRateToken()) throw new EngineError("RATE_LIMITED", "Demonstration rate limit reached. Try again in a few minutes.");
	const normalized = canonicalizeInput(redactSecrets(input.text));
	const existing = await findByIdempotency(idempotencyKey(normalized, input.evidenceClass));
	if (existing) return existing;
	const prev = await previousChainHash();
	const record = runEngine({
		originalText: input.text,
		evidenceClass: input.evidenceClass,
		scenarioId: input.scenarioId,
		nowIso: (/* @__PURE__ */ new Date()).toISOString(),
		prevChainHash: prev,
		sourceCommit: "workspace"
	});
	await insertRecord(record);
	const written = await getRecord(record.request_id);
	if (!written) throw new EngineError("AUDIT_PERSISTENCE_FAILURE", "Audit write did not read back. Decision withheld.");
	return written;
}
var seedPromise = null;
async function ensureSeeded() {
	if (seedPromise) return seedPromise;
	seedPromise = (async () => {
		if (((await (await getSql())`select count(*)::int as n from evaluations`)[0]?.n ?? 0) > 0) return;
		for (const s of SCENARIOS) {
			const prev = await previousChainHash();
			await insertRecord(runEngine({
				originalText: s.text,
				evidenceClass: s.evidence_class,
				scenarioId: s.id,
				nowIso: (/* @__PURE__ */ new Date()).toISOString(),
				prevChainHash: prev,
				sourceCommit: "workspace"
			}));
		}
	})().catch((err) => {
		seedPromise = null;
		throw err;
	});
	return seedPromise;
}
function runtimeManifest() {
	return {
		runtime_id: RUNTIME_ID,
		runtime_version: RUNTIME_VERSION,
		registry_id: REGISTRY_ID,
		registry_version: REGISTRY_VERSION,
		policy_version: POLICY_VERSION,
		schema_version: SCHEMA_VERSION,
		consensus_version: CONSENSUS_VERSION,
		artifact_id: artifactIdOf(),
		artifact_material_hash: sha256(artifactMaterial()),
		build_channel: "demonstration",
		protected_paths: [...PROTECTED_PATHS],
		source_commit: "workspace",
		environment: "demonstration"
	};
}
//#endregion
export { ensureSeeded, executeAndPersist, getRecord, listRecords, runtimeManifest };
