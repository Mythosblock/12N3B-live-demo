import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BANK_META } from "./inventory-dc-eGa2v.mjs";
import { i as cn } from "./router-DGHasSym.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-DWrgn2tJ.js
var import_jsx_runtime = require_jsx_runtime();
var BANKS = [
	"ethics",
	"security",
	"evidence"
];
function statusTone(status) {
	if (status === "pass") return "text-ship";
	if (status === "fail") return "text-reject";
	if (status === "hold") return "text-hold";
	return "text-muted";
}
function EvaluatorBoard({ evaluators, animate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 lg:grid-cols-3",
		children: BANKS.map((bank) => {
			const rows = evaluators.filter((e) => e.group === bank);
			const meta = BANK_META[bank];
			const pass = rows.filter((r) => r.status === "pass").length;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-surface p-4 shadow-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-4 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
						children: meta.n_of_b
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-xl text-fg",
						children: meta.name
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs text-muted tabular",
						children: [pass, "/4"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: rows.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("rounded-md border border-line bg-elevated px-3 py-2.5", animate && "replay-item"),
						style: { ["--i"]: i + BANKS.indexOf(bank) * 4 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-fg",
								children: row.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("font-mono text-[10px] tracking-wider uppercase", statusTone(row.status)),
								children: [row.status, row.veto ? " · veto" : ""]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-[10px] text-subtle",
							children: row.evaluator_id
						})]
					}, row.evaluator_id))
				})]
			}, bank);
		})
	});
}
function Button({ className, variant = "primary", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-opacity duration-150 ease-out disabled:cursor-not-allowed disabled:opacity-40", variant === "primary" && "bg-accent text-accent-fg hover:opacity-90 active:scale-[0.98]", variant === "secondary" && "border border-line-strong bg-elevated text-fg hover:border-accent/40", variant === "ghost" && "text-muted hover:text-fg", className),
		...props
	});
}
//#endregion
export { EvaluatorBoard as n, Button as t };
