//#region node_modules/.nitro/vite/services/ssr/assets/inventory-dc-eGa2v.js
var RUNTIME_ID = "EMO1";
var RUNTIME_VERSION = "1.0.0";
var REGISTRY_ID = "$12N3B";
var REGISTRY_VERSION = "1.0.0";
var SCHEMA_VERSION = "emo1-api-1.0.0";
var POLICY_VERSION = "emo1-policy-1.0.0";
var CONSENSUS_VERSION = "emo1-consensus-1.0.0";
var THRESHOLD_VERSION = "cnf-threshold-v1";
var AUDIT_SCHEMA_VERSION = "emo1-audit-1.0.0";
var PROTECTED_PATHS = [
	"src/lib/emo1/registry.ts",
	"src/lib/emo1/evaluators.ts",
	"src/lib/emo1/consensus.ts",
	"src/lib/emo1/policies.ts",
	"src/lib/emo1/engine.ts",
	"src/lib/emo1/transform.ts",
	"src/lib/emo1/identity.ts",
	"src/lib/emo1/persist.server.ts"
];
function artifactMaterial() {
	return [
		RUNTIME_ID,
		RUNTIME_VERSION,
		REGISTRY_ID,
		REGISTRY_VERSION,
		SCHEMA_VERSION,
		POLICY_VERSION,
		CONSENSUS_VERSION,
		THRESHOLD_VERSION,
		AUDIT_SCHEMA_VERSION
	].join("|");
}
var BANK_META = {
	ethics: {
		id: "ethics",
		name: "Ethics & safety",
		n_of_b: "3 of 4",
		purpose: "Prohibited conditions, escalation, semantic ethics, and policy ambiguity."
	},
	security: {
		id: "security",
		name: "Security & integrity",
		n_of_b: "3 of 4",
		purpose: "Trust-zone boundaries, injection, provenance completeness, isolation."
	},
	evidence: {
		id: "evidence",
		name: "Evidence & quality",
		n_of_b: "3 of 4",
		purpose: "Sufficiency, freshness, calibrated confidence, policy conformance."
	}
};
var EVALUATORS = [
	{
		id: "12n3b.ethics.semantic",
		name: "Semantic ethics",
		group: "ethics",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Scores deception, hidden action, and audience-sensitive harm language against the ethics policy.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "Deterministic policy match on structured features. HOLD on public high-impact ambiguity; FAIL on deceptive or harm-coded action."
	},
	{
		id: "12n3b.ethics.harm",
		name: "Harm / prohibited",
		group: "ethics",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: true,
		description: "Veto-capable. FAIL on prohibited conditions (unreviewed production weights, audit disable, safety override).",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "Any prohibited-condition hit is a veto FAIL. Absence of hits is PASS."
	},
	{
		id: "12n3b.ethics.escalation",
		name: "Escalation / review",
		group: "ethics",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Requires human review for new segments, policy change, or production-bound model action.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "HOLD when escalation conditions fire. PASS for routine documented internal release."
	},
	{
		id: "12n3b.ethics.ambiguity",
		name: "Policy ambiguity",
		group: "ethics",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Blocks silent pass when the request is underspecified or the policy fit is unclear.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "HOLD when ambiguity_score > 0.45. Cannot SHIP through this evaluator on unclear policy fit."
	},
	{
		id: "12n3b.security.boundary",
		name: "Security boundary",
		group: "security",
		type: "atomic",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Evaluates trust-zone and production-boundary movement.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "FAIL on unreviewed production ship. HOLD on trust-zone expansion. PASS if no boundary change."
	},
	{
		id: "12n3b.security.injection",
		name: "Injection / instruction",
		group: "security",
		type: "atomic",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: true,
		description: "Veto-capable. Treats attempts to override evaluators, policies, or audit as untrusted input — never as instructions.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "Injection markers are evidence of attack, not configuration. FAIL + veto. Original text is retained as data."
	},
	{
		id: "12n3b.security.provenance",
		name: "Provenance completeness",
		group: "security",
		type: "atomic",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Requires attributable sources for material claims.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "HOLD when claims lack source identity. PASS when citations are present and classed."
	},
	{
		id: "12n3b.security.isolation",
		name: "Isolation / trust zone",
		group: "security",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Flags unrestricted access, cross-tenant, or isolation-weakening language.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "HOLD/FAIL on isolation-risk features. PASS otherwise."
	},
	{
		id: "12n3b.evidence.sufficiency",
		name: "Evidence sufficiency",
		group: "evidence",
		type: "atomic",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Material claims must trace to identified evidence. Missing evidence cannot support SHIP.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "PASS only with cited, classed evidence. HOLD on missing or unsupported claims."
	},
	{
		id: "12n3b.evidence.freshness",
		name: "Freshness / source",
		group: "evidence",
		type: "atomic",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Applies the 45-day freshness window. Stale or unverifiable evidence cannot silently pass.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "fresh → PASS; stale/unknown/none → HOLD."
	},
	{
		id: "12n3b.evidence.confidence",
		name: "Confidence / calibration",
		group: "evidence",
		type: "model-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Seeded deterministic scorer. Low confidence cannot silently pass. Threshold cnf-threshold-v1 = 0.72.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0", "cnf-threshold-v1"],
		execution_semantics: "Score is a calibrated mix of evidence, ambiguity, and contradiction. Deterministic for identical inputs. HOLD below 0.72."
	},
	{
		id: "12n3b.evidence.policy",
		name: "Policy conformance",
		group: "evidence",
		type: "policy-based",
		version: "1.0.0",
		execution_location: "local-runtime",
		veto_capable: false,
		description: "Untrusted input cannot alter policy version, evaluator instructions, or consensus logic. Override attempts FAIL.",
		input_schema: "structured-request-1.0.0",
		output_schema: "evaluator-result-1.0.0",
		dependencies: ["emo1-policy-1.0.0"],
		execution_semantics: "FAIL on policy-override intent. The runtime policy version is never taken from user text."
	}
];
function evaluatorById(id) {
	return EVALUATORS.find((e) => e.id === id);
}
var REGISTRY_MANIFEST = {
	registry_id: REGISTRY_ID,
	registry_version: REGISTRY_VERSION,
	evaluator_count: EVALUATORS.length,
	banks: 3,
	quorum: "3 of 4 per bank; all three banks required for SHIP",
	veto_evaluators: EVALUATORS.filter((e) => e.veto_capable).map((e) => e.id)
};
var DISCLOSURES = [
	{
		id: "d-demo",
		title: "Demonstration environment",
		body: "This instance is a demonstration of the EMO1 runtime and $12N3B registry. It is not a production deployment and is not approved for operational decisions."
	},
	{
		id: "d-fixtures",
		title: "Fixture boundary",
		body: "Catalog scenarios are static fixtures. They run through the real evaluators and consensus table. They are not live retrieved evidence. Production mode, if enabled later, must not silently substitute fixtures."
	},
	{
		id: "d-providers",
		title: "Provider non-endorsement",
		body: "Named model providers in the dependency inventory are excluded from this demonstration. Listed, configured, or available does not mean invoked. Invoked does not mean decision-relevant. Nothing here is an endorsement by any provider."
	},
	{
		id: "d-local",
		title: "Local execution",
		body: "All twelve evaluators execute inside the EMO1 local runtime. No external model is called for scoring. Consensus is deterministic for identical input and configuration."
	},
	{
		id: "d-evidence",
		title: "Evidence limits",
		body: "Evidence is extracted from the submitted text (citations, dates, source phrases). The runtime does not retrieve documents from the internet. Unsupported claims are marked unsupported. Stale or missing evidence cannot support SHIP."
	},
	{
		id: "d-uncertainty",
		title: "Uncertainty",
		body: "Confidence is a calibrated deterministic score, not a statistical guarantee. Low confidence and policy ambiguity cannot silently pass."
	},
	{
		id: "d-observer",
		title: "Observer vs ledger",
		body: "The observer reads the durable audit ledger. Decision records are authoritative. Animated replays of evaluator order are projected visualizations of already-recorded results."
	},
	{
		id: "d-tenant",
		title: "Shared demonstration ledger",
		body: "This preview shares one demonstration tenant. Do not submit personal, confidential, or regulated data. Secrets and email-like strings are redacted before persistence. There is no per-user sign-in on this surface."
	},
	{
		id: "d-auth",
		title: "Access boundary",
		body: "Hosted production use requires authentication, tenant isolation, and signed artifacts. This demonstration enforces input size, rate limits, and fail-closed audit writes only."
	}
];
var DEFAULT_DISCLOSURE_IDS = DISCLOSURES.map((d) => d.id);
var DEPENDENCY_INVENTORY = [
	{
		id: "emo1-local-runtime",
		kind: "runtime",
		participation: "voting",
		invoked_in_demo: true,
		decision_relevant: true,
		note: "In-process EMO1 engine. All $12N3B evaluators execute here."
	},
	{
		id: "postgres-or-pglite",
		kind: "storage",
		participation: "informational",
		invoked_in_demo: true,
		decision_relevant: false,
		note: "Durable audit ledger. Neon when configured; PGLite in this preview. Storage is not a voting evaluator."
	},
	{
		id: "xai",
		kind: "model-provider",
		participation: "excluded",
		invoked_in_demo: false,
		decision_relevant: false,
		note: "Not invoked. Not decision-relevant. Listing is inventory, not endorsement."
	},
	{
		id: "openai",
		kind: "model-provider",
		participation: "excluded",
		invoked_in_demo: false,
		decision_relevant: false,
		note: "Not invoked. Not decision-relevant. Listing is inventory, not endorsement."
	},
	{
		id: "anthropic",
		kind: "model-provider",
		participation: "excluded",
		invoked_in_demo: false,
		decision_relevant: false,
		note: "Not invoked. Not decision-relevant. Listing is inventory, not endorsement."
	},
	{
		id: "identity-broker",
		kind: "identity",
		participation: "excluded",
		invoked_in_demo: false,
		decision_relevant: false,
		note: "Demonstration tenant is shared and unauthenticated. Identity services are not in the decision path."
	}
];
//#endregion
export { artifactMaterial as _, DEPENDENCY_INVENTORY as a, POLICY_VERSION as c, REGISTRY_MANIFEST as d, REGISTRY_VERSION as f, THRESHOLD_VERSION as g, SCHEMA_VERSION as h, DEFAULT_DISCLOSURE_IDS as i, PROTECTED_PATHS as l, RUNTIME_VERSION as m, BANK_META as n, DISCLOSURES as o, RUNTIME_ID as p, CONSENSUS_VERSION as r, EVALUATORS as s, AUDIT_SCHEMA_VERSION as t, REGISTRY_ID as u, evaluatorById as v };
