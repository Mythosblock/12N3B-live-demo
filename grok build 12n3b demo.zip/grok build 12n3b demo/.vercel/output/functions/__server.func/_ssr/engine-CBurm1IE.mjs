import { n as EngineError } from "./api-DALLPKdk.mjs";
import { _ as artifactMaterial, a as DEPENDENCY_INVENTORY, c as POLICY_VERSION, f as REGISTRY_VERSION, g as THRESHOLD_VERSION, h as SCHEMA_VERSION, i as DEFAULT_DISCLOSURE_IDS, m as RUNTIME_VERSION, n as BANK_META, p as RUNTIME_ID, r as CONSENSUS_VERSION, s as EVALUATORS, t as AUDIT_SCHEMA_VERSION, u as REGISTRY_ID, v as evaluatorById } from "./inventory-dc-eGa2v.mjs";
import { createHash, randomUUID } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-CBurm1IE.js
function sha256(input) {
	return createHash("sha256").update(input, "utf8").digest("hex");
}
function sortKeys(value) {
	if (Array.isArray(value)) return value.map(sortKeys);
	if (value && typeof value === "object") {
		const obj = value;
		const out = {};
		for (const k of Object.keys(obj).sort()) out[k] = sortKeys(obj[k]);
		return out;
	}
	return value;
}
function canonicalize(value) {
	return JSON.stringify(sortKeys(value));
}
function canonicalHash(value) {
	return sha256(canonicalize(value));
}
function newId(prefix) {
	return `${prefix}_${randomUUID().replace(/-/g, "").slice(0, 20)}`;
}
function redactSecrets(text) {
	return text.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, "[redacted-email]").replace(/\b(sk-[A-Za-z0-9]{16,})\b/g, "[redacted-key]").replace(/\bBearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [redacted]");
}
var POLICY = {
	version: POLICY_VERSION,
	bank_quorum: 3,
	confidence_threshold: .72,
	threshold_version: THRESHOLD_VERSION,
	max_input_chars: 8e3,
	evidence_fresh_days: 45,
	ambiguity_hold: .45,
	rate_limit_window_ms: 3e5,
	rate_limit_max: 16,
	veto_evaluators: ["12n3b.ethics.harm", "12n3b.security.injection"],
	prohibited_conditions: [
		"unreviewed production model weights",
		"disable or skip the audit ledger",
		"override or disable safety evaluators",
		"ship without human review when prohibited conditions apply"
	],
	escalation_conditions: [
		"new customer segment",
		"policy change",
		"production-bound model action",
		"trust-zone expansion"
	],
	injection_patterns: [
		{
			id: "inj.ignore-policy",
			re: /ignore (all )?(previous|prior|the) (instructions|policy|policies)/i,
			label: "ignore previous policy/instructions"
		},
		{
			id: "inj.you-are-now",
			re: /\byou are now\b/i,
			label: "role-rewrite ('you are now')"
		},
		{
			id: "inj.system-prompt",
			re: /system prompt/i,
			label: "system-prompt manipulation"
		},
		{
			id: "inj.jailbreak",
			re: /\bjailbreak\b/i,
			label: "jailbreak"
		},
		{
			id: "inj.override-safety",
			re: /override (all )?(safety|evaluators?|policy|policies)/i,
			label: "override safety/evaluators/policy"
		},
		{
			id: "inj.disable-controls",
			re: /disable (the )?(audit|evaluators?|safety)/i,
			label: "disable audit/evaluators/safety"
		},
		{
			id: "inj.skip-review",
			re: /skip (human )?review/i,
			label: "skip human review"
		},
		{
			id: "inj.set-policy-ver",
			re: /set policy version/i,
			label: "policy-version override attempt"
		}
	]
};
var VERB_RE = /\b(publish|release|ship|deploy|expand|allow|deny|override|skip|disable|grant|revoke|open|close|consider|cite|document)\b/gi;
var ASSET_RE = /\b(changelog|api|model(?:\s+weights)?|weights|evaluator(?:s)?|policy|audit|production|customer(?:\s+segment)?|release notes|prompt|runtime|ledger)\b/gi;
function uniq(xs) {
	return [...new Set(xs.map((s) => s.toLowerCase()))];
}
function hits(text, patterns) {
	const ids = [];
	const labels = [];
	for (const p of patterns) {
		p.re.lastIndex = 0;
		if (p.re.test(text)) {
			ids.push(p.id);
			labels.push(p.label);
		}
	}
	return {
		ids,
		labels
	};
}
function freshnessOf(text, cites) {
	if (!cites) return "none";
	if (/\b(last|past)\s+\d+\s+days?\b/i.test(text) || /\b(this (week|month)|today|yesterday|last week)\b/i.test(text)) {
		const m = text.match(/\b(?:last|past)\s+(\d+)\s+days?\b/i);
		if (m) {
			if (Number(m[1]) > POLICY.evidence_fresh_days) return "stale";
		}
		return "fresh";
	}
	if (/\b(last quarter|last year|historical|years ago)\b/i.test(text)) return "stale";
	return "unknown";
}
function intentOf(text, f) {
	if (f.injection || f.override_policy) return "override";
	if (/\b(publish|release|changelog)\b/i.test(text) && f.documentation) return "release";
	if (/\bdeploy|ship\b/i.test(text)) return "deployment";
	if (f.new_segment || /\bexpand\b/i.test(text)) return "access";
	if (f.policy_change) return "policy_change";
	if (/\b(should we|consider|what if)\b/i.test(text)) return "inquiry";
	return "unknown";
}
function canonicalizeInput(raw) {
	return raw.replace(/\u0000/g, "").normalize("NFC").replace(/\s+/g, " ").trim();
}
function extractFeatures(text) {
	const inj = hits(text, POLICY.injection_patterns);
	const evidencePhrases = [...text.matchAll(/\b(?:citing|cited|based on|according to|documented in)\s+([^,.]+)/gi)].map((m) => m[0].trim());
	const cites = evidencePhrases.length > 0 || /\bsigned release notes\b/i.test(text);
	if (cites && evidencePhrases.length === 0) evidencePhrases.push("signed release notes");
	let ambiguity = 0;
	if (/\b(consider|maybe|unclear|incomplete|limited|what if)\b/i.test(text)) ambiguity += .28;
	if (/\bnew customer segment\b/i.test(text)) ambiguity += .2;
	if (/\bpolicy fit is unclear\b/i.test(text)) ambiguity += .22;
	if (inj.ids.length) ambiguity += .15;
	ambiguity = Math.min(1, ambiguity);
	const prohibitedHits = [];
	if (/\bunreviewed (model )?weights\b/i.test(text)) prohibitedHits.push("unreviewed production model weights");
	if (/\baudit disabled\b/i.test(text) || /\bno audit\b/i.test(text) || /\bdisable (the )?audit\b/i.test(text)) prohibitedHits.push("disable or skip the audit ledger");
	if (/\boverride (all )?(safety|evaluators?)\b/i.test(text)) prohibitedHits.push("override or disable safety evaluators");
	if (/\bno human review\b/i.test(text) || /\bskip (human )?review\b/i.test(text)) prohibitedHits.push("ship without human review when prohibited conditions apply");
	const productionUrgency = /\b(production|prod)\b/i.test(text) && /\b(tonight|immediately|asap|now)\b/i.test(text);
	return {
		injection: inj.ids.length > 0,
		injection_hits: inj.labels,
		prohibited: prohibitedHits.length > 0,
		prohibited_hits: prohibitedHits,
		override_policy: /\boverride\b/i.test(text) && /\b(policy|evaluators?|safety)\b/i.test(text),
		skip_audit: /\b(disable|skip).{0,24}audit|audit disabled|no audit\b/i.test(text),
		skip_review: /\b(skip|no) (human )?review\b/i.test(text),
		unreviewed_weights: /\bunreviewed (model )?weights\b/i.test(text),
		production_urgency: productionUrgency,
		new_segment: /\bnew customer segment\b/i.test(text),
		boundary_change: /\b(production|trust[- ]zone|expand(?:ing)? the evaluation api)\b/i.test(text) && !/\balready-released\b/i.test(text),
		access_grant: /\b(grant|open access|unrestricted)\b/i.test(text),
		public_audience: /\bpublic\b/i.test(text) && !/\binternal\b/i.test(text),
		internal_audience: /\binternal\b/i.test(text),
		documentation: /\b(changelog|release notes|document(?:ing|ation)?)\b/i.test(text),
		already_released: /\balready-released\b/i.test(text),
		cites_evidence: cites,
		evidence_phrases: uniq(evidencePhrases),
		freshness: freshnessOf(text, cites),
		ambiguity,
		deception: /\b(hidden|secret deploy|cover up|mislead)\b/i.test(text),
		harm_language: /\b(harm|exploit|weapon|surveil(?:l)? without)\b/i.test(text),
		isolation_risk: /\b(cross-tenant|unrestricted access|disable isolation)\b/i.test(text),
		policy_change: /\b(policy change|change the policy|set policy version)\b/i.test(text),
		inquiry_only: /\b(should we|consider)\b/i.test(text) && !/\b(ship|deploy|publish)\b/i.test(text)
	};
}
function transformRequest(opts) {
	const normalized = canonicalizeInput(opts.original);
	const features = extractFeatures(normalized);
	const verbs = uniq(normalized.match(VERB_RE) ?? []);
	const assets = uniq(normalized.match(ASSET_RE) ?? []);
	const audience = features.internal_audience ? "internal" : features.public_audience ? "public" : /\bcustomer\b/i.test(normalized) ? "customer" : "unknown";
	let urgency = "routine";
	if (features.production_urgency || /\btonight|immediately|asap\b/i.test(normalized)) urgency = "immediate";
	else if (/\bexpedite|urgent\b/i.test(normalized)) urgency = "expedited";
	return {
		original_text: opts.original,
		normalized_text: normalized,
		intent: intentOf(normalized, features),
		action_verbs: verbs,
		assets,
		audience,
		claimed_evidence: features.evidence_phrases,
		risk_markers: [
			...features.injection_hits,
			...features.prohibited_hits,
			...features.new_segment ? ["new customer segment"] : [],
			...features.boundary_change ? ["boundary change"] : []
		],
		injection_markers: features.injection_hits,
		prohibited_markers: features.prohibited_hits,
		urgency,
		ambiguity_score: features.ambiguity,
		evidence_class: opts.evidenceClass,
		scenario_id: opts.scenarioId ?? null,
		features
	};
}
function result(id, status, score, confidence, findings, extra) {
	const def = evaluatorById(id);
	if (!def) throw new Error(`unknown evaluator ${id}`);
	const clamped = Math.max(0, Math.min(1, score));
	return {
		evaluator_id: def.id,
		name: def.name,
		group: def.group,
		type: def.type,
		version: def.version,
		status,
		score: clamped,
		confidence: Math.max(0, Math.min(1, confidence)),
		uncertainty: extra?.uncertainty ?? Math.max(0, Math.min(1, 1 - confidence)),
		veto: extra?.veto ?? false,
		findings,
		evidence_refs: extra?.evidence_refs ?? [],
		execution_location: "local-runtime",
		duration_ms: 0,
		output_hash: "",
		policy_version: POLICY_VERSION
	};
}
function semantic(s) {
	const f = s.features;
	if (f.deception || f.harm_language) return result("12n3b.ethics.semantic", "fail", .12, .86, [f.deception ? "Deceptive or hidden-action language is present." : "Harm-coded language is present.", "Ethics policy does not allow a silent pass on this class of request."]);
	if (f.injection) return result("12n3b.ethics.semantic", "hold", .28, .8, ["Instruction-like override language is treated as untrusted content, not as a policy change.", `Markers: ${f.injection_hits.join("; ")}.`]);
	if (s.audience === "public" && (f.boundary_change || f.unreviewed_weights)) return result("12n3b.ethics.semantic", "hold", .4, .7, ["Public-audience high-impact action without a completed ethics review."]);
	if (f.documentation && f.already_released && f.internal_audience) return result("12n3b.ethics.semantic", "pass", .91, .88, ["Routine internal documentation of already-released features. No deception or audience-sensitive harm markers."]);
	return result("12n3b.ethics.semantic", "pass", .78, .74, ["No deception or prohibited harm language detected in the structured request."]);
}
function harm(s) {
	const f = s.features;
	if (f.prohibited || f.unreviewed_weights || f.skip_audit && f.production_urgency) return result("12n3b.ethics.harm", "fail", .02, .95, [
		"Prohibited condition matched.",
		...f.prohibited_hits.map((h) => `Policy hit: ${h}.`),
		"This evaluator is veto-capable. A FAIL here cannot be outvoted."
	], { veto: true });
	return result("12n3b.ethics.harm", "pass", .93, .9, ["No prohibited-condition hits."]);
}
function escalation(s) {
	const f = s.features;
	const reasons = [];
	if (f.new_segment) reasons.push("New customer segment requires human review.");
	if (f.policy_change) reasons.push("Policy-change intent requires review.");
	if (f.unreviewed_weights || f.boundary_change && f.production_urgency) reasons.push("Production-bound model or boundary action requires review.");
	if (f.skip_review) reasons.push("Request attempts to skip human review.");
	if (reasons.length) return result("12n3b.ethics.escalation", "hold", .34, .82, reasons);
	return result("12n3b.ethics.escalation", "pass", .86, .84, ["No escalation condition fired. Routine path may proceed without additional review."]);
}
function ambiguity(s) {
	if (s.ambiguity_score > POLICY.ambiguity_hold) return result("12n3b.ethics.ambiguity", "hold", .38, .8, [`Ambiguity score ${s.ambiguity_score.toFixed(2)} exceeds ${POLICY.ambiguity_hold}.`, "Policy-ambiguous results cannot silently pass."]);
	return result("12n3b.ethics.ambiguity", "pass", .84, .83, [`Ambiguity score ${s.ambiguity_score.toFixed(2)} is within the pass band.`]);
}
function boundary(s) {
	const f = s.features;
	if (f.unreviewed_weights && f.production_urgency) return result("12n3b.security.boundary", "fail", .08, .93, ["Unreviewed weights crossing into production is a boundary FAIL."]);
	if (f.new_segment || f.boundary_change && !f.already_released && !f.documentation) return result("12n3b.security.boundary", "hold", .42, .78, ["Trust-zone or API-surface expansion without a completed boundary review."]);
	return result("12n3b.security.boundary", "pass", .88, .85, ["No security-boundary movement detected."]);
}
function injection(s) {
	const f = s.features;
	if (f.injection) return result("12n3b.security.injection", "fail", 0, .97, [
		"Untrusted input contains instruction-like override language.",
		...f.injection_hits.map((h) => `Pattern: ${h}.`),
		"This is scored as an attack on the control plane, not as a configuration change.",
		"Original wording is retained as data. Policy version is unchanged."
	], { veto: true });
	return result("12n3b.security.injection", "pass", .96, .94, ["No injection or evaluator-instruction manipulation markers."]);
}
function provenance(s, evidence) {
	const usable = evidence.filter((e) => e.validation_status === "validated");
	if (!s.features.cites_evidence || usable.length === 0) return result("12n3b.security.provenance", "hold", .3, .8, ["Material claims are not backed by attributable, validated sources.", "Unsupported claims cannot silently support SHIP."]);
	return result("12n3b.security.provenance", "pass", .87, .84, [`${usable.length} validated evidence item(s) with source identity.`], { evidence_refs: usable.map((e) => e.id) });
}
function isolation(s) {
	if (s.features.isolation_risk || s.features.access_grant) return result("12n3b.security.isolation", "hold", .33, .81, ["Isolation-weakening or unrestricted-access language is present."]);
	return result("12n3b.security.isolation", "pass", .9, .86, ["No isolation or cross-tenant weakening language."]);
}
function sufficiency(s, evidence) {
	const usable = evidence.filter((e) => e.supports_ship && e.validation_status === "validated");
	if (usable.length === 0) return result("12n3b.evidence.sufficiency", "hold", .22, .86, ["No validated evidence item is sufficient to support SHIP.", "Missing evidence is fail-closed."]);
	return result("12n3b.evidence.sufficiency", "pass", .86, .85, [`Sufficient evidence: ${usable.map((e) => e.source_identity).join(", ")}.`], { evidence_refs: usable.map((e) => e.id) });
}
function freshness(s, evidence) {
	if (s.features.freshness === "none" || evidence.length === 0) return result("12n3b.evidence.freshness", "hold", .24, .84, ["No dated evidence source. Freshness cannot be established."]);
	if (s.features.freshness === "stale" || evidence.some((e) => e.validation_status === "stale")) return result("12n3b.evidence.freshness", "hold", .31, .83, [`Evidence is outside the ${POLICY.evidence_fresh_days}-day freshness window.`, "Stale evidence cannot silently support SHIP."]);
	if (s.features.freshness === "unknown" || evidence.some((e) => e.validation_status === "unverifiable")) return result("12n3b.evidence.freshness", "hold", .4, .76, ["Evidence source time is unverifiable."]);
	return result("12n3b.evidence.freshness", "pass", .89, .86, [`Evidence is within the ${POLICY.evidence_fresh_days}-day freshness window.`]);
}
function confidence(s, evidence) {
	const f = s.features;
	let score = .62;
	if (f.cites_evidence) score += .14;
	if (f.freshness === "fresh") score += .1;
	if (f.internal_audience) score += .04;
	if (f.documentation && f.already_released) score += .08;
	if (f.ambiguity > .2) score -= f.ambiguity * .35;
	if (f.injection) score -= .35;
	if (f.prohibited) score -= .4;
	if (evidence.every((e) => e.validation_status !== "validated")) score -= .18;
	score = Math.max(.02, Math.min(.98, score));
	const conf = Math.max(.55, Math.min(.96, .7 + (f.cites_evidence ? .1 : 0) - f.ambiguity * .2));
	if (score < POLICY.confidence_threshold) return result("12n3b.evidence.confidence", "hold", score, conf, [`Calibrated score ${score.toFixed(2)} is below ${POLICY.threshold_version} threshold ${POLICY.confidence_threshold}.`, "Low-confidence results cannot silently pass."]);
	return result("12n3b.evidence.confidence", "pass", score, conf, [`Calibrated score ${score.toFixed(2)} meets ${POLICY.threshold_version}.`]);
}
function policyConformance(s) {
	const f = s.features;
	if (f.override_policy || f.policy_change || f.injection_hits.some((h) => h.includes("policy"))) return result("12n3b.evidence.policy", "fail", .05, .94, ["Request attempts to alter policy, evaluator instructions, or consensus logic.", `Authoritative policy version remains ${POLICY_VERSION}. User text is not a control channel.`]);
	return result("12n3b.evidence.policy", "pass", .92, .9, [`Policy version ${POLICY_VERSION} is server-side and unchanged by this request.`]);
}
var RUNNERS = {
	"12n3b.ethics.semantic": (s) => semantic(s),
	"12n3b.ethics.harm": (s) => harm(s),
	"12n3b.ethics.escalation": (s) => escalation(s),
	"12n3b.ethics.ambiguity": (s) => ambiguity(s),
	"12n3b.security.boundary": (s) => boundary(s),
	"12n3b.security.injection": (s) => injection(s),
	"12n3b.security.provenance": (s, e) => provenance(s, e),
	"12n3b.security.isolation": (s) => isolation(s),
	"12n3b.evidence.sufficiency": (s, e) => sufficiency(s, e),
	"12n3b.evidence.freshness": (s, e) => freshness(s, e),
	"12n3b.evidence.confidence": (s, e) => confidence(s, e),
	"12n3b.evidence.policy": (s) => policyConformance(s)
};
function runEvaluators(s, evidence) {
	return EVALUATORS.map((def) => {
		const started = Date.now();
		const runner = RUNNERS[def.id];
		if (!runner) return result(def.id, "unavailable", 0, 0, ["Evaluator runner is not registered. Fail-closed."]);
		const out = runner(s, evidence);
		out.duration_ms = Math.max(0, Date.now() - started);
		return out;
	});
}
var BANKS = [
	"ethics",
	"security",
	"evidence"
];
function bankResult(bank, rows) {
	const mine = rows.filter((r) => r.group === bank);
	const pass_count = mine.filter((r) => r.status === "pass").length;
	const hold_count = mine.filter((r) => r.status === "hold").length;
	const fail_count = mine.filter((r) => r.status === "fail" || r.status === "unavailable" || r.status === "timeout" || r.status === "malformed").length;
	let outcome = "hold";
	if (fail_count > 0 && pass_count < POLICY.bank_quorum) outcome = fail_count >= 2 ? "fail" : "hold";
	if (pass_count >= POLICY.bank_quorum && fail_count === 0) outcome = "pass";
	if (pass_count >= POLICY.bank_quorum && fail_count > 0) outcome = "hold";
	if (pass_count < POLICY.bank_quorum) outcome = fail_count >= 2 ? "fail" : "hold";
	const notes = outcome === "pass" ? `${pass_count} of 4 pass; quorum met.` : `${pass_count} pass / ${hold_count} hold / ${fail_count} fail; quorum is ${POLICY.bank_quorum} of 4 with zero fails.`;
	return {
		bank_id: bank,
		name: BANK_META[bank].name,
		quorum_required: POLICY.bank_quorum,
		pass_count,
		hold_count,
		fail_count,
		outcome,
		notes
	};
}
function decide(opts) {
	const { evaluators, structured, evidence } = opts;
	const bank_results = BANKS.map((b) => bankResult(b, evaluators));
	const vetoes = evaluators.filter((e) => e.veto && e.status === "fail").map((e) => e.evaluator_id);
	const minConf = evaluators.reduce((m, e) => Math.min(m, e.confidence), 1);
	const reasons = [];
	const unavailable = evaluators.filter((e) => e.status === "unavailable" || e.status === "timeout" || e.status === "malformed");
	let terminal = "HOLD";
	let rule_id = "H0";
	let mapping = "Fail-closed default HOLD.";
	let fail_closed = true;
	if (vetoes.includes("12n3b.security.injection")) {
		terminal = "REJECT";
		rule_id = "R2";
		mapping = "Injection veto (SEC.INJECTION FAIL) → REJECT.";
		reasons.push("Instruction-override / injection veto fired.");
		fail_closed = true;
	} else if (vetoes.includes("12n3b.ethics.harm")) {
		terminal = "REJECT";
		rule_id = "R3";
		mapping = "Harm/prohibited veto (ETH.HARM FAIL) → REJECT.";
		reasons.push("Prohibited-condition veto fired.");
		fail_closed = true;
	} else if (evaluators.find((e) => e.evaluator_id === "12n3b.evidence.policy" && e.status === "fail") && structured.features.override_policy) {
		terminal = "REJECT";
		rule_id = "R4";
		mapping = "Policy-override FAIL → REJECT.";
		reasons.push("Untrusted input attempted to change governance logic.");
		fail_closed = true;
	} else if (unavailable.length) {
		terminal = "HOLD";
		rule_id = "H1";
		mapping = "Unavailable, timeout, or malformed evaluator → HOLD. Cannot SHIP.";
		reasons.push(...unavailable.map((e) => `${e.evaluator_id} status ${e.status}.`));
	} else {
		const unmet = bank_results.filter((b) => b.outcome !== "pass");
		const lowConf = evaluators.find((e) => e.evaluator_id === "12n3b.evidence.confidence" && e.status !== "pass");
		const evidenceHold = evaluators.filter((e) => (e.evaluator_id === "12n3b.evidence.sufficiency" || e.evaluator_id === "12n3b.evidence.freshness") && e.status !== "pass");
		const amb = evaluators.find((e) => e.evaluator_id === "12n3b.ethics.ambiguity" && e.status === "hold");
		const esc = evaluators.find((e) => e.evaluator_id === "12n3b.ethics.escalation" && e.status === "hold");
		if (unmet.length) {
			terminal = "HOLD";
			rule_id = "H2";
			mapping = "Bank N-of-B not met → HOLD. All three banks must pass for SHIP.";
			reasons.push(...unmet.map((b) => `${b.name}: ${b.notes}`));
		}
		if (lowConf) {
			terminal = "HOLD";
			if (rule_id === "H2") rule_id = "H2+H3";
			else rule_id = "H3";
			mapping = "Low-confidence cannot silently pass → HOLD.";
			reasons.push(`Confidence below ${POLICY.confidence_threshold} (${THRESHOLD_VERSION}).`);
		}
		if (evidenceHold.length) {
			terminal = "HOLD";
			if (!rule_id.startsWith("H")) rule_id = "H4";
			else if (!rule_id.includes("H4")) rule_id = `${rule_id}+H4`;
			mapping = "Missing, stale, or unverifiable evidence cannot support SHIP → HOLD.";
			reasons.push(...evidenceHold.map((e) => e.findings[0] ?? e.evaluator_id));
		}
		if (amb) {
			terminal = "HOLD";
			if (!String(rule_id).includes("H5")) rule_id = rule_id === "H0" ? "H5" : `${rule_id}+H5`;
			reasons.push("Policy ambiguity cannot silently pass.");
		}
		if (esc) {
			terminal = "HOLD";
			if (!String(rule_id).includes("H6")) rule_id = rule_id === "H0" ? "H6" : `${rule_id}+H6`;
			reasons.push("Escalation / human-review condition fired.");
		}
		const allBanksPass = bank_results.every((b) => b.outcome === "pass");
		const evidenceOk = evidence.some((e) => e.supports_ship && e.validation_status === "validated");
		if (allBanksPass && evidenceOk && !lowConf && vetoes.length === 0 && unavailable.length === 0) {
			terminal = "SHIP";
			rule_id = "S1";
			mapping = "All three banks pass, no veto, evidence sufficient and fresh, confidence ≥ threshold → SHIP.";
			reasons.length = 0;
			reasons.push("N-of-B met in ethics, security, and evidence.");
			reasons.push("No veto-capable evaluator failed.");
			reasons.push("Evidence is identified, validated, and within freshness.");
			fail_closed = false;
		} else if (terminal !== "REJECT") {
			terminal = "HOLD";
			fail_closed = true;
			if (rule_id === "H0") {
				rule_id = "H7";
				mapping = "Disagreement or incomplete pass set → HOLD.";
			}
		}
	}
	const summary = `${terminal} — ${mapping}`;
	return {
		terminal,
		rule_id,
		summary,
		reasons: reasons.length ? reasons : [mapping],
		fail_closed,
		vetoes,
		bank_results,
		confidence: Number(minConf.toFixed(4)),
		confidence_threshold: POLICY.confidence_threshold,
		threshold_version: THRESHOLD_VERSION,
		mapping
	};
}
function artifactIdOf() {
	return `art_${sha256(artifactMaterial()).slice(0, 16)}`;
}
function evidenceFrom(structured, nowIso) {
	const f = structured.features;
	if (!f.cites_evidence) return [{
		id: "evd_none",
		source_identity: "none",
		acquisition_time: nowIso,
		freshness_limit_days: POLICY.evidence_fresh_days,
		validation_status: "missing",
		provenance: "No source identity was extracted from the request.",
		confidence: 0,
		content_hash: sha256("none"),
		classification: structured.evidence_class,
		excerpt: "",
		supports_ship: false
	}];
	return f.evidence_phrases.map((phrase, i) => {
		const validation = f.freshness === "fresh" ? "validated" : f.freshness === "stale" ? "stale" : f.freshness === "unknown" ? "unverifiable" : "unvalidated";
		return {
			id: `evd_${i + 1}`,
			source_identity: phrase,
			acquisition_time: nowIso,
			freshness_limit_days: POLICY.evidence_fresh_days,
			validation_status: validation,
			provenance: "Extracted from submitter text. Not independently retrieved.",
			confidence: validation === "validated" ? .82 : .35,
			content_hash: sha256(phrase),
			classification: structured.evidence_class,
			excerpt: phrase,
			supports_ship: validation === "validated"
		};
	});
}
function providerEvents(requestId, executionId) {
	return DEPENDENCY_INVENTORY.filter((d) => d.kind === "model-provider" || d.id === "emo1-local-runtime").map((d) => {
		const local = d.id === "emo1-local-runtime";
		return {
			provider_id: d.id,
			adapter_id: local ? "emo1-engine" : null,
			adapter_version: local ? RUNTIME_VERSION : null,
			request_id: requestId,
			execution_id: executionId,
			started_at: local ? (/* @__PURE__ */ new Date()).toISOString() : null,
			ended_at: local ? (/* @__PURE__ */ new Date()).toISOString() : null,
			status: local ? "completed" : "ignored",
			participation_mode: d.participation,
			credential_present: false,
			adapter_configured: local,
			integration_available: local,
			invoked: local,
			result_used: local,
			endorsement: false,
			decision_relevant: local,
			response_hash: null,
			timeout: false,
			error: null,
			note: d.note
		};
	});
}
function idempotencyKey(normalized, evidenceClass) {
	return sha256(`${REGISTRY_VERSION}|${POLICY_VERSION}|${evidenceClass}|${normalized}`);
}
function recordHashMaterial(record) {
	return canonicalHash({
		request_id: record.request_id,
		execution_id: record.execution_id,
		original_hash: record.original_hash,
		normalized_hash: record.normalized_hash,
		decision: record.decision,
		rule_id: record.decision_lineage.rule_id,
		evaluator_hashes: record.evaluators.map((e) => e.output_hash),
		registry_version: record.registry_version,
		policy_version: record.policy_version,
		artifact_id: record.artifact_id
	});
}
function chainHash(prev, recordHash) {
	return sha256(`${prev ?? "emo1-audit-genesis-v1"}|${recordHash}`);
}
function runEngine(opts) {
	const redacted = redactSecrets(opts.originalText);
	if (redacted.length > POLICY.max_input_chars) throw new EngineError("INPUT_TOO_LARGE", `Maximum length is ${POLICY.max_input_chars} characters.`);
	const normalized = canonicalizeInput(redacted);
	const structured = transformRequest({
		original: redacted,
		evidenceClass: opts.evidenceClass,
		scenarioId: opts.scenarioId
	});
	const requestId = newId("req");
	const executionId = newId("ex");
	const evidence = evidenceFrom(structured, opts.nowIso);
	const evaluators = runEvaluators(structured, evidence).map((row) => ({
		...row,
		output_hash: canonicalHash({
			id: row.evaluator_id,
			status: row.status,
			score: row.score,
			findings: row.findings,
			veto: row.veto
		})
	}));
	const lineage = decide({
		evaluators,
		structured,
		evidence
	});
	if (lineage.terminal !== "SHIP" && lineage.terminal !== "HOLD" && lineage.terminal !== "REJECT") throw new EngineError("UNKNOWN_STATE");
	const art = artifactIdOf();
	const providers = providerEvents(requestId, executionId);
	const original_hash = sha256(redacted);
	const normalized_hash = sha256(normalized);
	const draft = {
		request_id: requestId,
		execution_id: executionId,
		idempotency_key: idempotencyKey(normalized, opts.evidenceClass),
		artifact_id: art,
		runtime_id: RUNTIME_ID,
		runtime_version: RUNTIME_VERSION,
		registry_id: REGISTRY_ID,
		registry_version: REGISTRY_VERSION,
		policy_version: POLICY_VERSION,
		schema_version: SCHEMA_VERSION,
		consensus_version: CONSENSUS_VERSION,
		original_input: redacted,
		original_hash,
		normalized_input: normalized,
		normalized_hash,
		evidence_class: opts.evidenceClass,
		scenario_id: opts.scenarioId ?? null,
		structured,
		decision: lineage.terminal,
		decision_lineage: lineage,
		evaluators,
		banks: lineage.bank_results,
		evidence,
		providers,
		labels: {
			environment: "demonstration",
			decision_data: "authoritative",
			observer_view: "authoritative",
			replay: "projected",
			evidence_class: opts.evidenceClass
		},
		disclosures: [...DEFAULT_DISCLOSURE_IDS],
		supersedes: null
	};
	const record_hash = recordHashMaterial(draft);
	const chain_hash = chainHash(opts.prevChainHash, record_hash);
	return {
		...draft,
		audit: {
			status: "committed",
			schema_version: AUDIT_SCHEMA_VERSION,
			record_hash,
			chain_hash,
			prev_chain_hash: opts.prevChainHash,
			decided_at: opts.nowIso,
			ingested_at: opts.nowIso,
			integrity: "valid"
		}
	};
}
function verifyRecord(record) {
	const expected = recordHashMaterial(record);
	return {
		ok: expected === record.audit.record_hash,
		expected,
		actual: record.audit.record_hash
	};
}
//#endregion
export { artifactIdOf, sha256 as i, idempotencyKey, POLICY as n, redactSecrets as r, runEngine, canonicalizeInput as t, verifyRecord };
