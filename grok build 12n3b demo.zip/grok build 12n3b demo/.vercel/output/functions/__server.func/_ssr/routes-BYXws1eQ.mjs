import { o as __toESM } from "../_runtime.mjs";
import { V as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as cn, o as submitEvaluation, r as DecisionMark } from "./router-DGHasSym.mjs";
import { n as EvaluatorBoard, t as Button } from "./button-DWrgn2tJ.mjs";
import { t as SCENARIOS } from "./scenarios-CmXU2MmT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYXws1eQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const navigate = useNavigate();
	const [text, setText] = (0, import_react.useState)("");
	const [evidenceClass, setEvidenceClass] = (0, import_react.useState)("customer_provided");
	const [scenarioId, setScenarioId] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [record, setRecord] = (0, import_react.useState)(null);
	const remaining = 8e3 - text.length;
	const canSubmit = text.trim().length > 0 && !busy;
	const classes = (0, import_react.useMemo)(() => [
		["customer_provided", "Customer-provided"],
		["static_fixture", "Static fixture"],
		["synthetic", "Synthetic"]
	], []);
	async function onSubmit() {
		if (!canSubmit) return;
		setBusy(true);
		setError(null);
		const res = await submitEvaluation({ data: {
			text,
			evidenceClass,
			scenarioId
		} });
		setBusy(false);
		if (!res.ok) {
			setError(`${res.error.code}: ${res.error.message}`);
			return;
		}
		setRecord(res.record);
	}
	function applyScenario(id) {
		const s = SCENARIOS.find((x) => x.id === id);
		if (!s) return;
		setText(s.text);
		setEvidenceClass(s.evidence_class);
		setScenarioId(s.id);
		setRecord(null);
		setError(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] tracking-[0.22em] text-subtle uppercase",
						children: "EMO1 runtime · $12N3B registry"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl leading-[1.1] tracking-tight text-fg sm:text-5xl",
						children: "Submit a decision for structured evaluation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-sm leading-relaxed text-muted sm:text-base",
						children: "Plain-English proposals are preserved, normalized, and scored by twelve local evaluators in three banks. Consensus is fail-closed: SHIP, HOLD, or REJECT. No terminal state leaves this console without a durable audit record."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-line bg-surface p-4 shadow-panel sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "proposal",
							className: "text-sm font-medium text-fg",
							children: "Proposal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "proposal",
							value: text,
							onChange: (e) => {
								setText(e.target.value.slice(0, 8e3));
								setScenarioId(null);
								setEvidenceClass("customer_provided");
							},
							placeholder: "Describe a release, access change, or production action. Original wording is retained as data, never as a control instruction.",
							className: "mt-3 min-h-40 w-full resize-y rounded-lg border border-line bg-elevated px-3 py-3 text-sm leading-relaxed text-fg outline-none placeholder:text-subtle focus:border-accent/50"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("font-mono text-[11px] tabular", remaining < 200 ? "text-hold" : "text-subtle"),
								children: [remaining, " left"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: onSubmit,
								disabled: !canSubmit,
								children: busy ? "Evaluating" : "Evaluate"
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-reject",
							children: error
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "rounded-xl border border-line bg-surface p-4 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-fg",
							children: "Evidence class"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted",
							children: "Production mode is not enabled. Live retrieval is not performed. Classification is stored on the audit record."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-col gap-2",
							children: classes.map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 cursor-pointer items-center gap-3 rounded-md border border-line px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "evidence-class",
									checked: evidenceClass === value,
									onChange: () => {
										setEvidenceClass(value);
										if (value !== "static_fixture") setScenarioId(null);
									},
									className: "accent-accent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-fg",
									children: label
								})]
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm font-medium text-fg",
							children: "Static fixtures"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-col gap-2",
							children: SCENARIOS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => applyScenario(s.id),
								className: cn("rounded-md border px-3 py-3 text-left transition-colors duration-150", scenarioId === s.id ? "border-accent/50 bg-elevated" : "border-line hover:border-line-strong"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-fg",
									children: s.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: s.blurb
								})]
							}, s.id))
						})
					]
				})]
			}),
			record ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 rounded-xl border border-line bg-surface p-5 sm:flex-row sm:items-end sm:justify-between sm:p-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-[11px] tracking-[0.18em] text-subtle uppercase",
								children: "Authoritative decision"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionMark, {
									state: record.decision,
									rule: record.decision_lineage.rule_id
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-xl text-sm leading-relaxed text-muted",
								children: record.decision_lineage.summary
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 font-mono text-[11px] text-subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["request ", record.request_id] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["audit ", record.audit.status] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate",
									children: ["hash ", record.audit.record_hash.slice(0, 16)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "secondary",
									onClick: () => navigate({
										to: "/evaluations/$requestId",
										params: { requestId: record.request_id }
									}),
									children: "Open record"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-mono text-[11px] tracking-wide text-subtle uppercase",
						children: "Projected replay of recorded evaluator execution"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvaluatorBoard, {
							evaluators: record.evaluators,
							animate: true
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-12 grid gap-4 sm:grid-cols-3",
				children: [
					{
						k: "12",
						v: "Evaluators",
						d: "Canonical $12N3B registry, versioned and local."
					},
					{
						k: "3",
						v: "Banks",
						d: "Ethics, security, evidence. Quorum is 3 of 4."
					},
					{
						k: "0",
						v: "Silent SHIP",
						d: "Missing evidence, ambiguity, and vetoes cannot pass."
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-line bg-surface px-5 py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl text-fg",
							children: item.k
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-fg",
							children: item.v
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted",
							children: item.d
						})
					]
				}, item.v))
			})
		]
	});
}
//#endregion
export { Home as component };
